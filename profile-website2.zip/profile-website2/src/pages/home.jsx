import React from 'react';

const home = () => {
  return (
    <section className="flex flex-col items-center justify-center p-10 bg-white">
      <h1 className="text-4xl font-bold">Michael kaiser</h1>
      <h2 className="text-xl">I'm a Footballer</h2>
    
      <p>play for Bastard Munchen or <a href="https://fcbayern.com/en" className="text-xl text-red-500">FC Bayern Munich</a>.</p>
      <img src="https://i.pinimg.com/736x/49/eb/32/49eb32eb14239d014e3d69a0926e5d62.jpg"width="200px"></img>
      <div className="flex space-x-4">
        <a href="https://www.facebook.com/teerin.kittichaicharoen" className="text-xl">Facebook</a>
        <a href="https://www.instagram.com/peppapigpepperpoppy/" className="text-xl">Instagram</a>
        
      </div>
      <a href ="https://bluelock.fandom.com/wiki/Michael_Kaiser" className="mt-4 px-4 py-2 bg-blue-500 text-white">My Portfolio</a>
    </section>
  );
};

export default home;