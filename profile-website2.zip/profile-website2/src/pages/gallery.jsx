import React from 'react';

const gallery = () => {
  return (
    <section className="flex flex-col items-center justify-center p-10 bg-white">
      <h2 className="text-3xl font-bold">Gallery</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {/* Replace with actual images */}
        <div className="border p-2">
          <img src="https://i.redd.it/whats-the-best-worst-kaiser-goal-v0-ts40xhi90c8d1.jpg?width=2230&format=pjpg&auto=webp&s=ed4c4548ef74765f3df57465149edb6fa5cbf503" alt="Image 1" className="img-fluid" />
        </div>
        <div className="border p-2">
          <img src="https://i.redd.it/whats-the-best-worst-kaiser-goal-v0-mn6s6iac0c8d1.jpg?width=2230&format=pjpg&auto=webp&s=40997c2f72c14aee6553bcd31747d12795e44427" alt="Image 2" className="img-kais" />
        </div>
        <div className="border p-2">
          <img src="https://preview.redd.it/the-door-to-humanity-michael-kaiser-analysis-v0-3u9zg683z68d1.png?width=2234&format=png&auto=webp&s=c70530327c2e9ace496b8a821ffb663d6a6a28e7" />
        </div>
        <div className="border p-2">
          <img src="https://preview.redd.it/is-michael-kaisers-bicycle-kick-possible-in-real-life-v0-kmk2d7p2dmhc1.jpg?width=640&crop=smart&auto=webp&s=6927e86772547e5b094366781a1653bc9ebd97a9" />
        </div>
        <div className="border p-2">
          <img src="https://staticg.sportskeeda.com/editor/2024/07/42d11-17199411586441-1920.jpg" />
        </div>
        <div className="border p-2">
          <img src="https://i.redd.it/isagi-and-kaiser-chemical-reaction-idea-v0-v79tcsy92agc1.jpg?width=1046&format=pjpg&auto=webp&s=82758e91e9aa646a8d80629c60134acb3580dde3" />
        </div>
      </div>
    </section>
  );
};

export default gallery;