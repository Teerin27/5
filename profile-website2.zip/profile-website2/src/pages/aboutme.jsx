import React from 'react';

const aboutme = () => {
  return (
    <section className="flex flex-col items-center justify-center p-10 bg-white">
        <img src="https://i.pinimg.com/736x/b3/1e/64/b31e64f86809038abde8a9a3936877c0.jpg" width="200px"></img>
      <h2 className="text-3xl font-bold">About Me</h2>
      <h3 className="text-xl">Professional Athlete</h3>
      <p>I will dominate the world with my skills and ego</p>
      
      <a href ="https://bluelock.fandom.com/wiki/Michael_Kaiser/Synopsis" className="mt-4 px-4 py-2 bg-green-500 text-white">Read more</a>
    </section>
  );
};

export default aboutme;