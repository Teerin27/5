import React from 'react';
import Home from './pages/home';
import AboutMe from './pages/aboutme';
import Gallery from './pages/gallery';

function App() {
  return (
    <div className="font-sans">
      <Home />
      <AboutMe />
      <Gallery />
    </div>
  );
}

export default App;