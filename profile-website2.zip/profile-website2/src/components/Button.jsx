import React from "react";

const Button = ({ text, onClick, className }) => {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-lg transition duration-300 ease-in-out ${className}`}
    >
      {text}
    </button>
  );
};

export default Button;
