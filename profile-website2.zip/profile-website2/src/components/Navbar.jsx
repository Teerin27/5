import React from "react";
import Button from "./Button"; // Import the Button component

const Navbar = () => {
  return (
    <nav className="flex justify-between items-center p-4 bg-white shadow-md">
      {/* Website Name */}
      <h1 className="text-xl font-bold">Artist John</h1>

      {/* Navigation Links */}
      <div className="hidden md:flex space-x-6">
        <a href="#home" className="text-gray-700 hover:text-green-700">Home</a>
        <a href="#about" className="text-gray-700 hover:text-green-700">About Me</a>
        <a href="#gallery" className="text-gray-700 hover:text-green-700">Gallery</a>
      </div>

      {/* Contact Button */}
      <Button text="Contact" className="bg-green-700 text-white px-4 py-2" />
    </nav>
  );
};

export default Navbar;
