import { useState } from "react";
import "./App.css";

function App() {
  const [result, setResult] = useState(0);
  const [input, setInput] = useState("");

  const handleInputChange = (e) => {
    setInput(e.target.value);
  };

  const performOperation = (operation) => {
    const number = parseFloat(input);
    if (isNaN(number)) return; 

    switch (operation) {
      case "add":
        setResult(result+number);
        break;
      case "subtract":
        setResult(result-number);
        break;
      case "multiply":
        setResult(result*number);
        break;
      case "divide":
        if (number !== 0) {
          setResult(result/number);
        } else {
          alert("Cannot divide by zero!");
        }
        break;
      default:
        break;
    }
    setInput(""); //clear data
  };

  const resetInput = () => setInput("");
  const resetResult = () => setResult(0);

  return (
    <div className="container">
      <h1>Simple Calculator</h1>
      <div className="result-box">Result: {result}</div>
      <input
        type="text"
        value={input}
        onChange={handleInputChange}
        placeholder="Enter a number"
      />
      <div className="buttons">
        <button onClick={() => performOperation("add")}>Add</button>
        <button onClick={() => performOperation("subtract")}>Subtract</button>   
        <button onClick={() => performOperation("multiply")}>Multiply</button>
        <button onClick={() => performOperation("divide")}>Divide</button>
      </div>
      <div className="buttons">
        <button className="reset-input" onClick={resetInput}>Reset Input</button>
        <button className="reset-result" onClick={resetResult}>Reset Result</button>
      </div>
    </div>
  );
}

export default App;
